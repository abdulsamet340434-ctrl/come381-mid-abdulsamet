# ER Diyagramı: Online Alışveriş

```mermaid
erDiagram
    CUSTOMER ||--o{ CUSTOMER_ORDER : "places"
    CATEGORY ||--o{ PRODUCT : "contains"
    CUSTOMER_ORDER ||--o{ ORDER_ITEM : "includes"
    PRODUCT ||--o{ ORDER_ITEM : "appears in"
    CUSTOMER_ORDER ||--o{ PAYMENT : "paid by"

    CUSTOMER {
        int customer_id PK
        string full_name
        string email
        string phone
        date registered_on
    }
    CATEGORY {
        int category_id PK
        string name
    }
    PRODUCT {
        int product_id PK
        int category_id FK
        string name
        numeric price
        int stock_quantity
    }
    CUSTOMER_ORDER {
        int order_id PK
        int customer_id FK
        timestamp order_date
        string status
        string shipping_address
        timestamp shipped_at
    }
    ORDER_ITEM {
        int order_id PK, FK
        int product_id PK, FK
        int quantity
        numeric unit_price
    }
    PAYMENT {
        int payment_id PK
        int order_id FK
        numeric amount
        string method
        timestamp paid_at
    }
```
