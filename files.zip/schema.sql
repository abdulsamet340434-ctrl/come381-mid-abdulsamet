-- Online alışveriş şeması (PostgreSQL)

CREATE TABLE customer (
    customer_id   integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    full_name     text,
    email         text,
    phone         text,
    registered_on date
);

CREATE TABLE category (
    category_id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name        text
);

CREATE TABLE product (
    product_id     integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    category_id    integer REFERENCES category (category_id),
    name           text,
    price          numeric(10, 2),
    stock_quantity integer
);

-- "order" SQL'de ayrılmış kelime olduğu için customer_order kullanıldı
CREATE TABLE customer_order (
    order_id         integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    customer_id      integer REFERENCES customer (customer_id),
    order_date       timestamp,
    status           text,
    shipping_address text,
    shipped_at       timestamp
);

-- customer_order ile product arasındaki M:N ilişkinin ara tablosu
CREATE TABLE order_item (
    order_id   integer REFERENCES customer_order (order_id),
    product_id integer REFERENCES product (product_id),
    quantity   integer,
    unit_price numeric(10, 2),
    PRIMARY KEY (order_id, product_id)
);

CREATE TABLE payment (
    payment_id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_id   integer REFERENCES customer_order (order_id),
    amount     numeric(10, 2),
    method     text,
    paid_at    timestamp
);
