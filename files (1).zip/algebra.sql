-- algebra.sql: Bölüm D sorularının SQL karşılıkları (seed.sql'den sonra çalıştırın)

-- D1: Fiyatı 1000'den büyük ürünlerin adları (σ, π)
SELECT DISTINCT name
FROM product
WHERE price > 1000
ORDER BY name;

-- D2: Her sipariş kalemi için müşteri adı ve ürün adı (⋈), ilk 10 satır
SELECT o.order_id, c.full_name, p.name AS product_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN product p        ON p.product_id  = oi.product_id
ORDER BY o.order_id, p.product_id
LIMIT 10;

-- D3: Ya Electronics ya Books kategorisinden ürün sipariş etmiş müşteriler (∪)
SELECT c.customer_id, c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN product p        ON p.product_id  = oi.product_id
JOIN category cat     ON cat.category_id = p.category_id
WHERE cat.name = 'Electronics'
UNION
SELECT c.customer_id, c.full_name
FROM customer c
JOIN customer_order o ON o.customer_id = c.customer_id
JOIN order_item oi    ON oi.order_id   = o.order_id
JOIN product p        ON p.product_id  = oi.product_id
JOIN category cat     ON cat.category_id = p.category_id
WHERE cat.name = 'Books'
ORDER BY 1;

-- D4 (yol 1, EXCEPT): Hiç sipariş vermemiş müşteriler (−)
SELECT full_name
FROM customer
WHERE customer_id IN (
    SELECT customer_id FROM customer
    EXCEPT
    SELECT customer_id FROM customer_order
)
ORDER BY full_name;

-- D4 (yol 2, NOT EXISTS)
SELECT c.full_name
FROM customer c
WHERE NOT EXISTS (
    SELECT 1 FROM customer_order o WHERE o.customer_id = c.customer_id
)
ORDER BY c.full_name;

-- D5: Aynı kategorideki farklı ürün çiftleri (ρ ile kendisiyle join)
SELECT p1.name AS product_1, p2.name AS product_2, cat.name AS category
FROM product p1
JOIN product p2  ON p1.category_id = p2.category_id
                AND p1.product_id < p2.product_id
JOIN category cat ON cat.category_id = p1.category_id
ORDER BY p1.product_id, p2.product_id;

-- D6 (çift NOT EXISTS): Electronics kategorisindeki TÜM ürünleri sipariş etmiş müşteriler (÷)
SELECT c.full_name
FROM customer c
WHERE NOT EXISTS (
    SELECT 1
    FROM product p
    JOIN category cat ON cat.category_id = p.category_id
    WHERE cat.name = 'Electronics'
      AND NOT EXISTS (
          SELECT 1
          FROM customer_order o
          JOIN order_item oi ON oi.order_id = o.order_id
          WHERE o.customer_id = c.customer_id
            AND oi.product_id = p.product_id
      )
)
ORDER BY c.full_name;
