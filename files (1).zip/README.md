# Hafta 5, Ödev 2

## Çalıştırma sırası

```bash
psql -d come381 -f sql/schema.sql
psql -d come381 -f week-05/constraints.sql
psql -d come381 -f week-05/violations.sql
psql -d come381 -f week-05/seed.sql
psql -d come381 -f week-05/algebra.sql
```

`violations.sql` tabloları boşaltarak başladığı için `seed.sql` ondan sonra gelir.
Çıktıyı almak için: `psql -d come381 -f week-05/violations.sql > week-05/violations_output.txt 2>&1`
Windows'ta komutlara `-U postgres` ekle; Türkçe karakter sorunu olursa `set PGCLIENTENCODING=UTF8`.

## NULL testi (T17)

`customer_order.shipped_at` sütununda `CHECK (shipped_at >= order_date)` var ama `NOT NULL` yok. `NULL` eklediğimde
satır kabul edildi: `CHECK` yalnızca ifade `false` döndüğünde reddeder, `NULL >= tarih` ise `false` değil `NULL`
(bilinmiyor) döndürür. Yani `CHECK` tek başına bir sütunun dolu olmasını sağlamaz, bunun için `NOT NULL` gerekir.
Burada bu istediğim davranış: sipariş henüz kargolanmamış olabilir.

## Beklediğimden farklı çıkan

(violations.sql'i çalıştırdıktan sonra 2-3 cümleyle doldur.)

## CHECK ile yazamadığım kural

Bir siparişteki ödemelerin toplamı sipariş kalemlerinin toplamına eşit olmalı. Bu kural birden çok tabloya
baktığı için `CHECK` ile yazılamıyor; Hafta 8'de trigger ile yazılacak.
