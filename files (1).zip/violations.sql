-- violations.sql
-- Her constraint'i bilerek bozar. Çalıştırma:
--   psql -d come381 -f week-05/violations.sql > week-05/violations_output.txt 2>&1
\set VERBOSITY verbose

-- Hazırlık: tabloları boşalt, testlerin ihtiyaç duyduğu satırları ekle.
TRUNCATE payment, order_item, customer_order, product, category, customer
  RESTART IDENTITY CASCADE;

INSERT INTO customer (full_name, email, phone, registered_on)
VALUES ('Ayse Yilmaz', 'ayse@example.com', '0532 111 22 33', '2026-01-15');
INSERT INTO category (name) VALUES ('Electronics');
INSERT INTO product (category_id, name, price, stock_quantity)
VALUES (1, 'Wireless Mouse', 299.90, 50),
       (1, 'Mechanical Keyboard', 1499.00, 20);
INSERT INTO customer_order (customer_id, order_date, status, shipping_address, shipped_at)
VALUES (1, '2026-03-01 10:00', 'pending', 'Kadikoy, Istanbul', NULL);
INSERT INTO order_item (order_id, product_id, quantity, unit_price)
VALUES (1, 1, 2, 299.90);
INSERT INTO payment (order_id, amount, method, paid_at)
VALUES (1, 599.80, 'credit_card', '2026-03-01 10:05');

------------------------------------------------------------------
-- NOT NULL
------------------------------------------------------------------
-- T01 | customer.full_name NOT NULL | Beklenen: 23502
INSERT INTO customer (full_name, email, registered_on)
VALUES (NULL, 't01@example.com', '2026-02-01');

-- T02 | category.name NOT NULL | Beklenen: 23502
INSERT INTO category (name) VALUES (NULL);

-- T03 | product.price NOT NULL | Beklenen: 23502
INSERT INTO product (category_id, name, price, stock_quantity)
VALUES (1, 'No Price Item', NULL, 5);

-- T04 | customer_order.status NOT NULL | Beklenen: 23502
INSERT INTO customer_order (customer_id, order_date, status, shipping_address)
VALUES (1, '2026-03-05 10:00', NULL, 'Kadikoy, Istanbul');

-- T05 | order_item.quantity NOT NULL | Beklenen: 23502
INSERT INTO order_item (order_id, product_id, quantity, unit_price)
VALUES (1, 2, NULL, 1499.00);

-- T06 | payment.amount NOT NULL | Beklenen: 23502
INSERT INTO payment (order_id, amount, method, paid_at)
VALUES (1, NULL, 'credit_card', '2026-03-01 11:00');

------------------------------------------------------------------
-- UNIQUE
------------------------------------------------------------------
-- T07 | uq_customer_email | Beklenen: 23505
INSERT INTO customer (full_name, email, registered_on)
VALUES ('Duplicate Person', 'ayse@example.com', '2026-02-02');

-- T08 | uq_category_name | Beklenen: 23505
INSERT INTO category (name) VALUES ('Electronics');

-- T09 | uq_product_category_name (çok sütunlu) | Beklenen: 23505
INSERT INTO product (category_id, name, price, stock_quantity)
VALUES (1, 'Wireless Mouse', 350.00, 5);

-- T10 | order_item_pkey (aynı ürün aynı siparişe iki kez) | Beklenen: 23505
INSERT INTO order_item (order_id, product_id, quantity, unit_price)
VALUES (1, 1, 1, 299.90);

------------------------------------------------------------------
-- CHECK
------------------------------------------------------------------
-- T11 | chk_product_price_positive | Beklenen: 23514
INSERT INTO product (category_id, name, price, stock_quantity)
VALUES (1, 'Free Item', 0, 5);

-- T12 | chk_product_stock_non_negative | Beklenen: 23514
INSERT INTO product (category_id, name, price, stock_quantity)
VALUES (1, 'Negative Stock Item', 10.00, -1);

-- T13 | chk_product_stock_non_negative | Beklenen: OK (sınır: stok tam 0)
INSERT INTO product (category_id, name, price, stock_quantity)
VALUES (1, 'Out Of Stock Item', 10.00, 0);

-- T14 | chk_order_status | Beklenen: 23514
INSERT INTO customer_order (customer_id, order_date, status, shipping_address)
VALUES (1, '2026-03-06 10:00', 'lost', 'Kadikoy, Istanbul');

-- T15 | chk_order_shipped_after_order | Beklenen: 23514
INSERT INTO customer_order (customer_id, order_date, status, shipping_address, shipped_at)
VALUES (1, '2026-03-07 10:00', 'shipped', 'Kadikoy, Istanbul', '2026-03-06 10:00');

-- T16 | chk_order_shipped_after_order | Beklenen: OK (sınır: aynı an)
INSERT INTO customer_order (customer_id, order_date, status, shipping_address, shipped_at)
VALUES (1, '2026-03-08 10:00', 'shipped', 'Kadikoy, Istanbul', '2026-03-08 10:00');

-- T17 | NULL testi: shipped_at CHECK'li ama NOT NULL değil | Beklenen: OK
-- CHECK ifadesi NULL dönerse satır reddedilmez; yalnızca false reddeder.
INSERT INTO customer_order (customer_id, order_date, status, shipping_address, shipped_at)
VALUES (1, '2026-03-09 10:00', 'pending', 'Kadikoy, Istanbul', NULL);

-- T18 | chk_order_item_quantity_positive | Beklenen: 23514
INSERT INTO order_item (order_id, product_id, quantity, unit_price)
VALUES (1, 2, 0, 1499.00);

-- T19 | chk_order_item_quantity_positive | Beklenen: OK (sınır: adet tam 1)
INSERT INTO order_item (order_id, product_id, quantity, unit_price)
VALUES (1, 2, 1, 1499.00);

-- T20 | chk_order_item_unit_price_positive | Beklenen: 23514
INSERT INTO order_item (order_id, product_id, quantity, unit_price)
VALUES (1, 3, 1, -5.00);

-- T21 | chk_payment_amount_positive | Beklenen: 23514
INSERT INTO payment (order_id, amount, method, paid_at)
VALUES (1, 0, 'credit_card', '2026-03-01 12:00');

-- T22 | chk_payment_method | Beklenen: 23514
INSERT INTO payment (order_id, amount, method, paid_at)
VALUES (1, 100.00, 'bitcoin', '2026-03-01 12:00');

------------------------------------------------------------------
-- FOREIGN KEY: INSERT yönü (olmayan ebeveyne bağlanmak)
------------------------------------------------------------------
-- T23 | fk_customer_order_customer | Beklenen: 23503
INSERT INTO customer_order (customer_id, order_date, status, shipping_address)
VALUES (999, '2026-03-10 10:00', 'pending', 'Nowhere');

-- T24 | fk_product_category | Beklenen: 23503
INSERT INTO product (category_id, name, price, stock_quantity)
VALUES (999, 'Orphan Product', 10.00, 1);

-- T25 | fk_order_item_product | Beklenen: 23503
INSERT INTO order_item (order_id, product_id, quantity, unit_price)
VALUES (1, 999, 1, 10.00);

-- T26 | fk_order_item_order | Beklenen: 23503
INSERT INTO order_item (order_id, product_id, quantity, unit_price)
VALUES (999, 1, 1, 10.00);

-- T27 | fk_payment_order | Beklenen: 23503
INSERT INTO payment (order_id, amount, method, paid_at)
VALUES (999, 10.00, 'credit_card', '2026-03-01 12:00');

------------------------------------------------------------------
-- FOREIGN KEY: DELETE / UPDATE yönü (çocuğu olan ebeveyni silmek)
------------------------------------------------------------------
-- T28 | fk_customer_order_customer (RESTRICT) | Beklenen: 23503
DELETE FROM customer WHERE customer_id = 1;

-- T29 | fk_order_item_product (RESTRICT) | Beklenen: 23503
DELETE FROM product WHERE product_id = 1;

-- T30 | fk_product_category (RESTRICT) | Beklenen: 23503
DELETE FROM category WHERE category_id = 1;

-- T31 | fk_payment_order (RESTRICT; siparişin ödemesi var) | Beklenen: 23503
DELETE FROM customer_order WHERE order_id = 1;

-- T32 | fk_customer_order_customer (UPDATE yönü, çocuk tarafı) | Beklenen: 23503
-- Not: customer_id GENERATED ALWAYS olduğu için ebeveynin id'sini
-- UPDATE ile değiştirmek zaten 428C9 verir; bu yüzden çocuk tarafını deniyoruz.
UPDATE customer_order SET customer_id = 999 WHERE order_id = 1;
