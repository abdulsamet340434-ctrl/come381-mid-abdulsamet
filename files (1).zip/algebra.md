# Bölüm D: İlişkisel cebir ve hesap

Veri: `seed.sql` (7 müşteri, 3 kategori, 8 ürün, 8 sipariş, 14 sipariş kalemi, 6 ödeme).
SQL karşılıkları `algebra.sql` dosyasında, soru numarasıyla.

**Gösterim notu.** `product` ve `category` tablolarının ikisinde de `name` sütunu var; doğal join (⋈)
yanlışlıkla bu sütunda da eşleştirirdi. Bu yüzden kategori adını önce yeniden adlandırıyorum:

```
C = ρ category_name←name ( category )
```

---

## D1: σ selection ve π projection

**Soru:** Fiyatı 1000'den büyük ürünlerin adları.

```
π name ( σ price > 1000 ( product ) )
```

**Sonuç:**

| name |
|---|
| Mechanical Keyboard |
| Noise Cancelling Headphones |

**DISTINCT notu:** Cebir küme olduğu için tekrar yoktur. `name` tek başına tekil değil (`uq_product_category_name`
yalnızca kategori + ad ikilisini tekil yapıyor), bu yüzden SQL'de `DISTINCT` kullandım.

**İlişkisel hesap (tuple relational calculus):**

```
{ t.name | product(t) ∧ t.price > 1000 }
```

---

## D2: ⋈ join

**Soru:** Her sipariş kalemi için sipariş numarası, müşteri adı ve ürün adı (ilk 10 satır).

```
π order_id, full_name, name ( customer ⋈ customer_order ⋈ order_item ⋈ product )
```

**Sonuç (10 satır):**

| order_id | full_name | product_name |
|---|---|---|
| 1 | Ayse Yilmaz | Wireless Mouse |
| 1 | Ayse Yilmaz | Mechanical Keyboard |
| 2 | Ayse Yilmaz | USB-C Hub |
| 2 | Ayse Yilmaz | Noise Cancelling Headphones |
| 3 | Mehmet Kaya | SQL Basics |
| 3 | Mehmet Kaya | Database Design |
| 4 | Elif Demir | Wireless Mouse |
| 4 | Elif Demir | Mechanical Keyboard |
| 4 | Elif Demir | USB-C Hub |
| 5 | Can Aydin | Desk Lamp |

**DISTINCT notu:** Gerekmez. `order_id` projeksiyonda olduğu ve `(order_id, product_id)` ara tablonun anahtarı
olduğu için her satır zaten tekil. `order_id`'yi çıkarsaydım Elif Demir'in Wireless Mouse'u iki ayrı siparişte
alması (sipariş 4 ve 8) tekrar eden satır üretirdi.

---

## D3: ∪ union

**Soru:** Ya Electronics ya Books kategorisinden ürün sipariş etmiş müşteriler.

```
B(k) = π customer_id, full_name ( σ category_name = k (
         customer ⋈ customer_order ⋈ order_item ⋈ product ⋈ C ) )

B('Electronics') ∪ B('Books')
```

**Sonuç:**

| customer_id | full_name |
|---|---|
| 1 | Ayse Yilmaz |
| 2 | Mehmet Kaya |
| 3 | Elif Demir |
| 5 | Zeynep Sahin |

**DISTINCT notu:** Gerekmez. SQL'de `UNION` (`UNION ALL` değil) tekrarları zaten eler; cebirdeki küme birleşimiyle
aynı davranır. Ayse'nin Electronics'ten birçok ürünü olsa da sonuçta bir kez görünür.

---

## D4: − difference

**Soru:** Hiç sipariş vermemiş müşteriler.

```
π full_name ( customer ⋈ ( π customer_id ( customer ) − π customer_id ( customer_order ) ) )
```

**Sonuç** (`EXCEPT` ve `NOT EXISTS` aynı sonucu verdi):

| full_name |
|---|
| Burak Celik |
| Selin Arslan |

**DISTINCT notu:** Gerekmez. `customer_id` anahtar olduğu için her müşteri en fazla bir kez gelir; `EXCEPT` ayrıca
tekrarları kendisi eler.

**İlişkisel hesap:**

```
{ t.full_name | customer(t) ∧ ¬∃o ( customer_order(o) ∧ o.customer_id = t.customer_id ) }
```

---

## D5: ρ rename ile tablonun kendisiyle join'i

**Soru:** Aynı kategorideki farklı ürün çiftleri (her çift bir kez).

```
π p1.name, p2.name, p1.category_id (
  ρ p1 ( product )  ⋈ p1.category_id = p2.category_id ∧ p1.product_id < p2.product_id  ρ p2 ( product ) )
```

`p1.product_id < p2.product_id` koşulu hem ürünün kendisiyle eşleşmesini hem de (A,B) ile (B,A) tekrarını engeller.

**Sonuç (8 satır):**

| product_1 | product_2 | category |
|---|---|---|
| Wireless Mouse | Mechanical Keyboard | Electronics |
| Wireless Mouse | USB-C Hub | Electronics |
| Wireless Mouse | Noise Cancelling Headphones | Electronics |
| Mechanical Keyboard | USB-C Hub | Electronics |
| Mechanical Keyboard | Noise Cancelling Headphones | Electronics |
| USB-C Hub | Noise Cancelling Headphones | Electronics |
| SQL Basics | Database Design | Books |
| Desk Lamp | Coffee Mug | Home |

**DISTINCT notu:** Gerekmez. `<` koşulu her çifti tam bir kez ürettiği için tekrar olmaz.

---

## D6: ÷ division

**Soru:** Electronics kategorisindeki **tüm** ürünleri sipariş etmiş müşteriler.

```
P = π customer_id, product_id ( customer_order ⋈ order_item )
E = π product_id ( σ category_name = 'Electronics' ( product ⋈ C ) )

π full_name ( customer ⋈ ( P ÷ E ) )
```

**Sonuç:**

| full_name |
|---|
| Ayse Yilmaz |

Electronics'te 4 ürün var (Mouse, Keyboard, USB-C Hub, Headphones). Ayse hepsini almış. Elif Demir "neredeyse" aday:
3 farklı Electronics ürünü almış (Headphones eksik) ve Mouse'u iki ayrı siparişte almış; doğru sorgu onu eler.

**Yöntem:** Çift `NOT EXISTS` seçtim. Cümlenin kendisini ("müşterinin almadığı hiçbir Electronics ürünü yok")
birebir yazıyor ve saymaya dayanmadığı için aynı ürünün iki kez alınmasından etkilenmiyor. `GROUP BY ... HAVING COUNT(...)`
yolu `COUNT(DISTINCT ...)` kullanılmazsa Elif'i yanlışlıkla sonuca katar.

**DISTINCT notu:** Gerekmez. Sorgu `customer` tablosundan satır seçiyor, her müşteri en fazla bir kez gelir.
