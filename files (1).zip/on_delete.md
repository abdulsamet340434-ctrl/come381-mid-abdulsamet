# Bölüm C: Silme politikası

| Foreign key | Ebeveyn → çocuk | Seçimin | Neden | Diğer seçenek neden olmadı |
|---|---|---|---|---|
| `fk_product_category` | category → product | `RESTRICT` | Ürünü olan bir kategorinin silinmesi ürünleri kategorisiz bırakırdı; önce ürünler taşınmalı ya da silinmeli | `CASCADE` yanlışlıkla bütün ürün kataloğunu silebilirdi |
| `fk_customer_order_customer` | customer → customer_order | `RESTRICT` | Siparişler ve ödemeler ticari kayıttır; müşteri silinince kaybolmamalı | `CASCADE` geçmiş siparişleri ve satış kayıtlarını yok ederdi; `SET NULL` sütun `NOT NULL` olduğu için zaten çalışmazdı |
| `fk_order_item_order` | customer_order → order_item | `CASCADE` | Sipariş kalemi, siparişi olmadan anlamsız; sipariş silinirse kalemleri de gitmeli | `RESTRICT` siparişi silmeden önce kalemleri tek tek silmeyi zorunlu kılardı |
| `fk_order_item_product` | product → order_item | `RESTRICT` | Geçmiş siparişlerde geçen ürün silinirse faturalar bozulur | `CASCADE` geçmiş siparişlerin kalemlerini sessizce silerdi |
| `fk_payment_order` | customer_order → payment | `RESTRICT` | Ödeme kaydı finansal bir kayıttır; ödemesi olan sipariş silinemez | `CASCADE` yapılmış ödemelerin kaydını yok ederdi |

İki farklı politika kullanıldı: `CASCADE` (1 foreign key) ve `RESTRICT` (4 foreign key). `SET NULL` kullanmadım;
ilgili sütunların hepsi iş kuralı gereği `NOT NULL`.

## CASCADE kanıtı

`seed.sql` yüklendikten sonra çalıştırılır. Sipariş 5 (Can Aydin, ödemesi yok) 2 kalem içeriyor.
`BEGIN`/`ROLLBACK` ile veri bozulmadan test ediliyor.

```sql
BEGIN;
SELECT count(*) AS siparis_once FROM customer_order WHERE order_id = 5;
SELECT count(*) AS kalem_once   FROM order_item     WHERE order_id = 5;
DELETE FROM customer_order WHERE order_id = 5;
SELECT count(*) AS siparis_sonra FROM customer_order WHERE order_id = 5;
SELECT count(*) AS kalem_sonra   FROM order_item     WHERE order_id = 5;
ROLLBACK;
```

Beklenen sonuç: `1 / 2 / 0 / 0`.

**Çıktı (kendi psql çıktını buraya yapıştır):**

```
(buraya yapıştır)
```

## RESTRICT ile NO ACTION farkı

İkisi de bağlı çocuk satır varken ebeveyni silmeyi engeller; fark kontrolün zamanında: `NO ACTION` (varsayılan)
kontrolü ifadenin sonunda yapar ve constraint `DEFERRABLE` ise işlemin (transaction) sonuna ertelenebilir,
`RESTRICT` ise hemen kontrol eder ve ertelenemez.
