-- seed.sql: Bölüm D sorguları için küçük veri seti.
-- violations.sql'den sonra çalışır; önce tabloları boşaltır.
TRUNCATE payment, order_item, customer_order, product, category, customer
  RESTART IDENTITY CASCADE;

INSERT INTO customer (full_name, email, phone, registered_on) VALUES
  ('Ayse Yilmaz',   'ayse@example.com',   '0532 111 22 33', '2026-01-15'),
  ('Mehmet Kaya',   'mehmet@example.com', '0533 222 33 44', '2026-01-20'),
  ('Elif Demir',    'elif@example.com',   NULL,             '2026-02-03'),
  ('Can Aydin',     'can@example.com',    '0535 444 55 66', '2026-02-10'),
  ('Zeynep Sahin',  'zeynep@example.com', '0536 555 66 77', '2026-03-01'),
  ('Burak Celik',   'burak@example.com',  NULL,             '2026-03-12'),
  ('Selin Arslan',  'selin@example.com',  '0538 777 88 99', '2026-04-02');

INSERT INTO category (name) VALUES ('Electronics'), ('Books'), ('Home');

INSERT INTO product (category_id, name, price, stock_quantity) VALUES
  (1, 'Wireless Mouse',               299.90,  50),   -- 1
  (1, 'Mechanical Keyboard',         1499.00,  20),   -- 2
  (1, 'USB-C Hub',                    649.50,  35),   -- 3
  (2, 'SQL Basics',                   189.00, 100),   -- 4
  (2, 'Database Design',              245.00,  60),   -- 5
  (3, 'Desk Lamp',                    399.00,  40),   -- 6
  (3, 'Coffee Mug',                    79.90, 200),   -- 7
  (1, 'Noise Cancelling Headphones', 2899.00,  12);   -- 8

INSERT INTO customer_order (customer_id, order_date, status, shipping_address, shipped_at) VALUES
  (1, '2026-03-01 10:00', 'paid',      'Kadikoy, Istanbul',  NULL),                 -- 1
  (1, '2026-03-15 14:30', 'delivered', 'Kadikoy, Istanbul',  '2026-03-17 10:00'),   -- 2
  (2, '2026-03-20 09:15', 'shipped',   'Cankaya, Ankara',    '2026-03-22 09:00'),   -- 3
  (3, '2026-04-02 18:45', 'paid',      'Bornova, Izmir',     NULL),                 -- 4
  (4, '2026-04-10 11:00', 'pending',   'Nilufer, Bursa',     NULL),                 -- 5
  (5, '2026-04-18 16:20', 'cancelled', 'Konak, Izmir',       NULL),                 -- 6
  (2, '2026-05-01 12:00', 'delivered', 'Cankaya, Ankara',    '2026-05-03 10:00'),   -- 7
  (3, '2026-05-10 08:50', 'paid',      'Bornova, Izmir',     NULL);                 -- 8

INSERT INTO order_item (order_id, product_id, quantity, unit_price) VALUES
  (1, 1, 2,  299.90), (1, 2, 1, 1499.00),
  (2, 3, 1,  649.50), (2, 8, 1, 2899.00),
  (3, 4, 1,  189.00), (3, 5, 1,  245.00),
  (4, 1, 1,  299.90), (4, 2, 1, 1499.00), (4, 3, 1, 649.50),
  (5, 6, 2,  399.00), (5, 7, 4,   79.90),
  (6, 1, 1,  299.90),
  (7, 7, 1,   79.90),
  (8, 1, 1,  299.90);   -- Elif (3) Mouse'u ikinci kez aldı: COUNT tuzağı için

INSERT INTO payment (order_id, amount, method, paid_at) VALUES
  (1, 2098.80, 'credit_card',      '2026-03-01 10:05'),
  (2, 3548.50, 'bank_transfer',    '2026-03-15 14:40'),
  (3,  434.00, 'cash_on_delivery', '2026-03-22 13:00'),
  (4, 2448.40, 'credit_card',      '2026-04-02 18:50'),
  (7,   79.90, 'credit_card',      '2026-05-01 12:05'),
  (8,  299.90, 'credit_card',      '2026-05-10 09:00');
