-- constraints.sql
-- sql/schema.sql'den SONRA çalışır; iş kurallarını constraint olarak ekler.

------------------------------------------------------------------
-- 1) Foreign key'ler: isimsiz olanları sil, isimli ve silme politikalı ekle
------------------------------------------------------------------
ALTER TABLE product         DROP CONSTRAINT product_category_id_fkey;
ALTER TABLE customer_order  DROP CONSTRAINT customer_order_customer_id_fkey;
ALTER TABLE order_item      DROP CONSTRAINT order_item_order_id_fkey;
ALTER TABLE order_item      DROP CONSTRAINT order_item_product_id_fkey;
ALTER TABLE payment         DROP CONSTRAINT payment_order_id_fkey;

-- Her ürün var olan bir kategoriye bağlı olmalı; ürünü olan kategori silinemez.
ALTER TABLE product
  ADD CONSTRAINT fk_product_category
  FOREIGN KEY (category_id) REFERENCES category (category_id)
  ON DELETE RESTRICT;

-- Her sipariş var olan bir müşteriye ait olmalı; siparişi olan müşteri silinemez.
ALTER TABLE customer_order
  ADD CONSTRAINT fk_customer_order_customer
  FOREIGN KEY (customer_id) REFERENCES customer (customer_id)
  ON DELETE RESTRICT;

-- Sipariş kalemi var olan bir siparişe ait olmalı; sipariş silinirse kalemleri de silinir.
ALTER TABLE order_item
  ADD CONSTRAINT fk_order_item_order
  FOREIGN KEY (order_id) REFERENCES customer_order (order_id)
  ON DELETE CASCADE;

-- Sipariş kalemi var olan bir ürüne işaret etmeli; siparişlerde geçen ürün silinemez.
ALTER TABLE order_item
  ADD CONSTRAINT fk_order_item_product
  FOREIGN KEY (product_id) REFERENCES product (product_id)
  ON DELETE RESTRICT;

-- Ödeme var olan bir siparişe ait olmalı; ödemesi olan sipariş silinemez.
ALTER TABLE payment
  ADD CONSTRAINT fk_payment_order
  FOREIGN KEY (order_id) REFERENCES customer_order (order_id)
  ON DELETE RESTRICT;

------------------------------------------------------------------
-- 2) NOT NULL: boş kalmaması gereken sütunlar
------------------------------------------------------------------
-- Her müşterinin adı, e-postası ve kayıt tarihi olmalı (telefon isteğe bağlı).
ALTER TABLE customer ALTER COLUMN full_name     SET NOT NULL;
ALTER TABLE customer ALTER COLUMN email         SET NOT NULL;
ALTER TABLE customer ALTER COLUMN registered_on SET NOT NULL;

-- Her kategorinin adı olmalı.
ALTER TABLE category ALTER COLUMN name SET NOT NULL;

-- Her ürünün kategorisi, adı, fiyatı ve stok miktarı olmalı.
ALTER TABLE product ALTER COLUMN category_id    SET NOT NULL;
ALTER TABLE product ALTER COLUMN name           SET NOT NULL;
ALTER TABLE product ALTER COLUMN price          SET NOT NULL;
ALTER TABLE product ALTER COLUMN stock_quantity SET NOT NULL;

-- Her siparişin müşterisi, tarihi, durumu ve teslimat adresi olmalı.
-- shipped_at bilerek NOT NULL değil: sipariş henüz kargolanmamış olabilir.
ALTER TABLE customer_order ALTER COLUMN customer_id      SET NOT NULL;
ALTER TABLE customer_order ALTER COLUMN order_date       SET NOT NULL;
ALTER TABLE customer_order ALTER COLUMN status           SET NOT NULL;
ALTER TABLE customer_order ALTER COLUMN shipping_address SET NOT NULL;

-- Her sipariş kaleminin adedi ve o anki birim fiyatı olmalı.
ALTER TABLE order_item ALTER COLUMN quantity   SET NOT NULL;
ALTER TABLE order_item ALTER COLUMN unit_price SET NOT NULL;

-- Her ödemenin siparişi, tutarı, yöntemi ve zamanı olmalı.
ALTER TABLE payment ALTER COLUMN order_id SET NOT NULL;
ALTER TABLE payment ALTER COLUMN amount   SET NOT NULL;
ALTER TABLE payment ALTER COLUMN method   SET NOT NULL;
ALTER TABLE payment ALTER COLUMN paid_at  SET NOT NULL;

------------------------------------------------------------------
-- 3) UNIQUE
------------------------------------------------------------------
-- İki müşteri aynı e-posta adresini kullanamaz.
ALTER TABLE customer
  ADD CONSTRAINT uq_customer_email UNIQUE (email);

-- İki kategori aynı ada sahip olamaz.
ALTER TABLE category
  ADD CONSTRAINT uq_category_name UNIQUE (name);

-- Aynı kategoride aynı adlı iki ürün olamaz (çok sütunlu).
ALTER TABLE product
  ADD CONSTRAINT uq_product_category_name UNIQUE (category_id, name);

-- Not: bir siparişte aynı ürün iki satır olamaz kuralı, order_item'ın
-- PRIMARY KEY (order_id, product_id) tanımıyla zaten korunuyor.

------------------------------------------------------------------
-- 4) CHECK
------------------------------------------------------------------
-- Ürün fiyatı sıfırdan büyük olmalı.
ALTER TABLE product
  ADD CONSTRAINT chk_product_price_positive CHECK (price > 0);

-- Stok miktarı negatif olamaz (0 olabilir: stokta yok demek).
ALTER TABLE product
  ADD CONSTRAINT chk_product_stock_non_negative CHECK (stock_quantity >= 0);

-- Sipariş durumu yalnızca tanımlı değerlerden biri olabilir.
ALTER TABLE customer_order
  ADD CONSTRAINT chk_order_status
  CHECK (status IN ('pending', 'paid', 'shipped', 'delivered', 'cancelled'));

-- Bir sipariş verilmeden önce kargolanamaz (iki sütun karşılaştırması).
-- shipped_at NULL ise (henüz kargolanmadı) kural false dönmez, kabul edilir.
ALTER TABLE customer_order
  ADD CONSTRAINT chk_order_shipped_after_order
  CHECK (shipped_at >= order_date);

-- Sipariş kaleminin adedi en az 1 olmalı.
ALTER TABLE order_item
  ADD CONSTRAINT chk_order_item_quantity_positive CHECK (quantity > 0);

-- Sipariş kaleminin birim fiyatı sıfırdan büyük olmalı.
ALTER TABLE order_item
  ADD CONSTRAINT chk_order_item_unit_price_positive CHECK (unit_price > 0);

-- Ödeme tutarı sıfırdan büyük olmalı.
ALTER TABLE payment
  ADD CONSTRAINT chk_payment_amount_positive CHECK (amount > 0);

-- Ödeme yöntemi yalnızca tanımlı değerlerden biri olabilir.
ALTER TABLE payment
  ADD CONSTRAINT chk_payment_method
  CHECK (method IN ('credit_card', 'bank_transfer', 'cash_on_delivery'));
