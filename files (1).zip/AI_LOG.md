# AI_LOG

## Ödev 1
Claude'a senaryomu (online alışveriş) verip ER diyagramı (`docs/er.md`) ve `sql/schema.sql` taslağını yazdırdım.
Taslağı kendi çalıştırıp kontrol ettim. (kontrol ettiysen buraya ne bulduğunu yaz)

## Ödev 2
**Genel kullanım:** Claude'a ödev dosyasını verip `constraints.sql`, `violations.sql`, `on_delete.md`, `seed.sql`,
`algebra.md` ve `algebra.sql` taslaklarını yazdırdım. Çıktıları PostgreSQL'de kendim çalıştırıp kontrol ettim.
(gerçekten yaptığını buraya yaz)

**Bölüm E, D6 denemesi:** (doldur)
1. Prompt'um (aynen): ...
2. Gelen sorgu: ...
3. Kendi verimdeki sonuç ve karşılaştırma: ...
4. Yanıltan veri durumu: `seed.sql`'de Elif Demir (müşteri 3) Wireless Mouse'u iki ayrı siparişte almış ve
   Electronics'ten 4. ürünü (Headphones) hiç almamış. `COUNT(*)` ile yazılmış bir division sorgusu onu yanlışlıkla
   sonuca katar.
